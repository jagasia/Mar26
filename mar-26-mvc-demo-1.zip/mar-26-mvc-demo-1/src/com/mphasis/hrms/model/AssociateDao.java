package com.mphasis.hrms.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class AssociateDao {

	private HibernateTemplate ht;

	public AssociateDao() {}
	
	public AssociateDao(HibernateTemplate ht) {
		super();
		this.ht = ht;
	}
	public HibernateTemplate getHt() {
		return ht;
	}
	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}

	@Transactional
	public Serializable create(Associate associate) {
		return ht.save(associate);
	}
	public List<Associate> read() {
		return ht.loadAll(Associate.class);
	}
	public Associate read(Long associateId) {
		return ht.get(Associate.class, associateId);
	}
	@Transactional
	public void update(Associate associate) {
		ht.update(associate);
	}
	@Transactional
	public void delete(Long associateId) {
		ht.delete(read(associateId));
	}
	

}
