package com.mphasis.hrms.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.Min;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Associate {
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	@Min(value = 100, message = "Associate Id should be minimum 100")
	private Long associateId;
	private String firstName;
	private String lastName;	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dateOfJoining;
	private String gender;
	@Column(columnDefinition = "LONGBLOB")
	@Lob
	private byte[] picture;
	transient SimpleDateFormat sdf;
	transient SimpleDateFormat sdf2;
	public Associate() 
	{
		sdf=new SimpleDateFormat("dd-MMM-yy");
		sdf2=new SimpleDateFormat("yyyy-MM-dd");
	}
	public Associate(Long associateId, String firstName, String lastName, Date dateOfJoining, String gender,
			byte[] picture) {
		this();
		this.associateId = associateId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfJoining = dateOfJoining;
		this.gender = gender;
		this.picture = picture;
	}
	public Associate(String firstName, String lastName, Date dateOfJoining, String gender,
			byte[] picture) {
		this();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfJoining = dateOfJoining;
		this.gender = gender;
		this.picture = picture;
	}
	public Long getAssociateId() {
		return associateId;
	}
	public void setAssociateId(Long associateId) {
		this.associateId = associateId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public String getDateOfJoining1() {
		return sdf.format(dateOfJoining);
	}

	public String getDateOfJoining2() {
		return sdf2.format(dateOfJoining);
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public byte[] getPicture() {
		return picture;
	}
	
	public String getPicture1()
	{
		String x=Base64.encodeBase64String(picture);
		return x;
	}
	
	public void setPicture(byte[] picture) {
		this.picture = picture;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", dateOfJoining=" + sdf.format(dateOfJoining) + ", gender=" + gender
				+ "]";
	}
	
}

