package com.mphasis.hrms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@RequestMapping("/employee")
@Controller
public class MyController {
	

	
	@RequestMapping("/one")
	public String login()
	{
		return "login";
	}
	
	@PostMapping("/validate")
	public ModelAndView validate(String username, String password)
	{
		ModelAndView mv=new ModelAndView();
		mv.addObject("username", username);
		mv.addObject("role", "admin");
		mv.setViewName("home");
		return mv;
	}
	
	@GetMapping("/validate")
	@ResponseBody
	public String validateMethod()
	{
		return "You cannot reach this by browser addres ";
	}
}
