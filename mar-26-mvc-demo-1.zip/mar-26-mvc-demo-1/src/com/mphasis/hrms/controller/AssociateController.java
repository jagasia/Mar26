package com.mphasis.hrms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.hrms.model.Associate;
import com.mphasis.hrms.model.AssociateDao;

@MultipartConfig
@Controller
@RequestMapping("/associate")
public class AssociateController {
	
//	  @InitBinder
//	    public void initBinder(WebDataBinder binder) {
//	        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
//	        dateFormat.setLenient(false);
//	        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
//	    }
	
	@RequestMapping("/")
	public ModelAndView home()
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		AssociateDao adao=(AssociateDao) ctx.getBean("adao");
		List<Associate> associates = adao.read();
		ModelAndView mv=new ModelAndView();
		mv.setViewName("associate");
		mv.addObject("associate", new Associate());
		mv.addObject("associates", associates);
		return mv;
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
//	public void add(@ModelAttribute("assoicate") Associate associate,@RequestParam("picture") MultipartFile picture) throws IOException
	@ResponseBody
	public ModelAndView add(@Valid @ModelAttribute("assoicate") Associate associate, BindingResult result, HttpSession session) throws IOException
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		AssociateDao adao=(AssociateDao) ctx.getBean("adao");
		
		ModelAndView mv=new ModelAndView();
		System.out.println(result.getErrorCount());
		if(result.hasErrors())
		{			
			mv.addObject("associate", associate);
			
			mv.setViewName("associate");
			return mv;
		}
		adao.create(associate);
		mv.setViewName("upload");
//		mv.addObject("associate", associate);
		session.setAttribute("associate", associate);
		return mv;
	}
	
	@RequestMapping("/test")
	public ModelAndView test(HttpSession session)
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("upload");
//		mv.addObject("associate", associate);
		session.setAttribute("associate", new Associate());
		return mv;
	}

	@RequestMapping(value="/savePicture", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView savePicture(@RequestParam("picture") MultipartFile picture, HttpSession session) throws IOException
	{
		//System.out.println(picture.getBytes().length);
		if(picture.getBytes().length==0)
		{
			session.removeAttribute("associate");
			return home();
		}
		byte[] data = picture.getBytes();
		Associate associate = (Associate) session.getAttribute("associate");
		associate.setPicture(data);
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		AssociateDao adao=(AssociateDao) ctx.getBean("adao");
		adao.update(associate);		
		return home();
	}
}
