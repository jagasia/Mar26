package com.mphasis.hrms.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.hrms.model.Branch;
import com.mphasis.hrms.model.BranchDao;


@Controller
@RequestMapping("/branch")
public class BranchController {
	
	
	@RequestMapping("/")
	public ModelAndView home()
	{
		//retrieve all branches as List<Branch> and store it in model and redirect to index page
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		BranchDao bdao = (BranchDao) ctx.getBean("bdao");
	
		List<Branch> branches = bdao.read();
		
		ModelAndView mv=new ModelAndView();
		mv.addObject("branches", branches);
		mv.addObject("branch",new Branch());
		mv.setViewName("index");
		return mv;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/add", params="add")
//	@ResponseBody
	public ModelAndView addBranch(@ModelAttribute("branch") Branch branch)
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		BranchDao bdao=(BranchDao) ctx.getBean("bdao");
		bdao.create(branch);
		ModelAndView mv = refresh(bdao);
		return mv;
	}	
	
	@RequestMapping(method = RequestMethod.POST, value = "/add", params = "modify")
	@ResponseBody
	public ModelAndView updateBranch(@ModelAttribute("branch") Branch branch)
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		BranchDao bdao=(BranchDao) ctx.getBean("bdao");
		bdao.update(branch);
		ModelAndView mv = refresh(bdao);
		return mv;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/add", params = "delete")
	@ResponseBody
	public ModelAndView deleteBranch(@ModelAttribute("branch") Branch branch)
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		BranchDao bdao=(BranchDao) ctx.getBean("bdao");
		bdao.delete(branch.getBid());
//		ModelAndView mv = refresh(bdao);
		return home();
	}
	
	
	private ModelAndView refresh(BranchDao bdao) {
		List<Branch> branches = bdao.read();
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index");
		mv.addObject("branches", branches);
		return mv;
	}
}
